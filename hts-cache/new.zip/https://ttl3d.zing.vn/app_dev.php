<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="google-site-verification" content="xPSgBSfWXd5bk31ICazGl1WvpG3B1J4j5Cg9P6V8OZo" />
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="1days" />
<title>Siêu phẩm kiếm hiệp 3D thời đại mới do VNG độc quyền phát hành</title>
<meta name="description" content="Game online 3D đình đám mang cốt truyện nổi tiếng Kim Dung cùng định hướng phát triển game hấp dẫn, tham gia Closed Beta ngày 10/10/2014"/>
<meta name="keywords" content=""/>
<meta property="og:title" content="Siêu phẩm kiếm hiệp 3D thời đại mới do VNG độc quyền phát hành"/>
<meta property="og:description" content="Game online 3D đình đám mang cốt truyện nổi tiếng Kim Dung cùng định hướng phát triển game hấp dẫn, tham gia Closed Beta ngày 10/10/2014"/>
<link rel="shortcut icon" href="//img.zing.vn/products/ks3d/skin-2014/images/favicon.ico" />
<meta name="robots" content="index,follow" />
<meta name="revisit-after" content="1days" />

<meta property="fb:app_id" content="781279451938935">
<meta property="og:image" content="//img.zing.vn/products/ks3d/skin-2014/images/thumbshare.jpg"/>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Barlow&display=swap">
    <link rel="stylesheet" href="//img.zing.vn/products/vendor/swiper/2019/swiper.min.css">
    <link rel="stylesheet" href="//img.zing.vn/products/ks3d/skin-2021/css-full/style.css">
    <link rel="stylesheet" href="https://chat.support.vnggames.com/cslivechat/app.css">
    <script>(function() {
  var _fbq = window._fbq || (window._fbq = []);
  if (!_fbq.loaded) {
    var fbds = document.createElement('script');
    fbds.async = true;
    fbds.src = '//connect.facebook.net/en_US/fbds.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(fbds, s);
    _fbq.loaded = true;
  }
  _fbq.push(['addPixelId', '615216428555838']);
})();
window._fbq = window._fbq || [];
window._fbq.push(['track', 'PixelInitialized', {}]);
</script>
    <!-- Google tag (gtag.js) POP -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-6LYWXMS54K"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-6LYWXMS54K');
        </script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-M9SM2Z5');</script>
<!-- End Google Tag Manager --></head>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M9SM2Z5"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->    <!-- Google Tag Manager -->
    <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-PLV8DQ" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-PLV8DQ');</script> 
    <!-- End Google Tag Manager -->
    <nav class="nav">
        <div class="container d-flex">
            <div class="nav__left">
                <a href="//ttl3d.zing.vn/app_dev.php/index.html">
                    <img src="//img.zing.vn/products/ks3d/skin-2021/images/logo.png" alt="">
                </a>
            </div>
            <div class="nav__center">
                <ul>
    					
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/index.html" 
						class="nav-home active" 
						rel="" 
						title="Trang chủ" 
						target="_self" 
					>
						Trang chủ
					</a>
			    			</li>
							
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/tin-tuc/danh-sach.1.html" 
						class="nav-news " 
						rel="" 
						title="Tin tức" 
						target="_self" 
					>
						Tin tức
					</a>
			    			</li>
							
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/su-kien/danh-sach.1.html" 
						class="nav-events " 
						rel="" 
						title="Sự kiện" 
						target="_self" 
					>
						Sự kiện
					</a>
			    			</li>
							
								
					
				
		
					<li>
			    			        <a  
						class="nav-guide"
						rel=""
						href="#"
						title="Hướng dẫn"
						target="_self"
					>
						Hướng dẫn
					</a>
					<span class="btn-img arrow"></span>
			        <ul>
			            					
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/bai-viet/huong-dan/tai-game-ttl-3d.html" 
						class=" " 
						rel="" 
						title="Hướng Dẫn Cài Đặt" 
						target="_self" 
					>
						Hướng Dẫn Cài Đặt
					</a>
			    			</li>
							
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/bai-viet/huong-dan/giao-dien-tro-choi.html" 
						class=" " 
						rel="" 
						title="Tân Thủ Nhập Môn" 
						target="_self" 
					>
						Tân Thủ Nhập Môn
					</a>
			    			</li>
							
																			
		
					<li>
			    			        <a  
						href="//ttl3d.zing.vn/app_dev.php/bai-viet/huong-dan/cap-1-cap-20.html" 
						class=" " 
						rel="" 
						title="Hướng Dẫn Theo Cấp" 
						target="_self" 
					>
						Hướng Dẫn Theo Cấp
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/su-do.html" 
						class=" " 
						rel="nofollow" 
						title="Hệ Thống Xã Hội" 
						target="_self" 
					>
						Hệ Thống Xã Hội
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/bang-hoi.html" 
						class=" " 
						rel="nofollow" 
						title="Hệ Thống Liên Minh" 
						target="_self" 
					>
						Hệ Thống Liên Minh
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/gioi-thieu-tran-thu.html" 
						class=" " 
						rel="nofollow" 
						title="Hệ Thống Trân Thú" 
						target="_self" 
					>
						Hệ Thống Trân Thú
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/cau-ca.html" 
						class=" " 
						rel="nofollow" 
						title="Kỹ Năng Sống" 
						target="_self" 
					>
						Kỹ Năng Sống
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/am-khi.html" 
						class=" " 
						rel="nofollow" 
						title="Hệ Thống Trang Bị" 
						target="_self" 
					>
						Hệ Thống Trang Bị
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/dieu-van-trang-bi.html" 
						class=" " 
						rel="nofollow" 
						title="Thao Tác Trang Bị" 
						target="_self" 
					>
						Thao Tác Trang Bị
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/tran-long-ky-cuoc.html" 
						class=" " 
						rel="nofollow" 
						title="Hệ Thống Phụ Bản" 
						target="_self" 
					>
						Hệ Thống Phụ Bản
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://ttl3d.zing.vn/bai-viet/huong-dan/huong-dan-nap-bac.html" 
						class=" " 
						rel="nofollow" 
						title="Hướng Dẫn Nạp Thẻ" 
						target="_self" 
					>
						Hướng Dẫn Nạp Thẻ
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://dieukhoantrochoi.zing.vn/tanthienlong3d" 
						class=" " 
						rel="nofollow" 
						title="Quy Định Trò Chơi" 
						target="_blank" 
					>
						Quy Định Trò Chơi
					</a>
			    			</li>
			
			        </ul>
			    			</li>
							
								
					
				
		
					<li>
			    			        <a  
						href="#" 
						class="nav-gallery " 
						rel="" 
						title="Thư viện" 
						target="_self" 
					>
						Thư viện
					</a>
			    			</li>
							
								
					
				
		
					<li>
			    			        <a  
						class="nav-forum"
						rel=""
						href="#"
						title="Cộng Đồng"
						target="_self"
					>
						Cộng Đồng
					</a>
					<span class="btn-img arrow"></span>
			        <ul>
			            					
												
					<li>
			    			        <a  
						href="https://www.facebook.com/ttl3d" 
						class=" " 
						rel="nofollow" 
						title="Fanpage" 
						target="_blank" 
					>
						Fanpage
					</a>
			    			</li>
			
			        </ul>
			    			</li>
							
												
					<li>
			    			        <a  
						href="https://support.vnggames.com/products/tan-thien-long-3d-316-2b61c790bd821b7c568afa7701f9145c/problems" 
						class="nav-support " 
						rel="nofollow" 
						title="Hỗ trợ" 
						target="_blank" 
					>
						Hỗ trợ
					</a>
			    			</li>
							
												
					<li>
			    			        <a  
						href="http://dieukhoantrochoi.zing.vn/tanthienlong3d" 
						class=" " 
						rel="nofollow" 
						title="Điều Khoản" 
						target="_blank" 
					>
						Điều Khoản
					</a>
			    			</li>
			
</ul>

            </div>
        </div>
    </nav>
    <div class="outer">
        <div class="Rating Rating_vng_18">
            <img src="//img.zing.vn/products/vendor/general/rating/images/vng-18.jpg" alt="">
        </div>
        <div class="wrapper--outer">
            <div class="container">
                <div class="offset-header"></div>
                <div class="wrapper grid">
                    <div class="control-abilities">
                        <a href="http://ttl3d.zing.vn/bai-viet/huong-dan/tai-game-ttl-3d.html" class="btn-img btn-download-game">
                            <img src="//img.zing.vn/products/ks3d/skin-2021/images/btn-download-game.gif" alt="">
                        </a>
                        <a href="https://new.pay.zing.vn/product/tanthienlong3d" class="btn-img btn-topup"></a>
                        <a href="https://id.zing.vn/v2/register" class="btn-img btn-register" onclick="ga('send', 'event', 'Dang ky', 'Button Image', 'Homepage', 1);" target="_blank"></a>
                        <a href="https://support.vnggames.com/products/passport-zingid-230-aa5a5cbf15d4936b6dc7a5482cc7bba9/problems" class="btn-img btn-hotline"></a>
                    </div>
                    <div class="main-banner">
                        <div class="swiper-container" id="homeBanner">
  <div class="swiper-wrapper">
                <div class="swiper-slide">
        <a
          href="https://ttl3d.zing.vn/su-kien/tuyet-dinh-song-hung/phan-thuong-3338.html"
          target="_blank"
          onclick="ga('send', 'event', 'Event Header', 'position 0', '#', 1);"
        >
          <img src="//img.zing.vn/upload/ks3d/source/Banner/banner-mainsite/2021/tuyetdinh.png" alt="Thiên Lòng Kỳ Tài 22">
        </a>
      </div>
                <div class="swiper-slide">
        <a
          href="https://ttl3d.zing.vn/su-kien/may-chu-moi-thien-long-37/noi-dung-3369.html"
          target="_blank"
          onclick="ga('send', 'event', 'Event Header', 'position 1', '#', 1);"
        >
          <img src="//img.zing.vn/upload/ks3d/source/Banner/banner-mainsite/2022/tl37.png" alt="Thiên Long 36">
        </a>
      </div>
      </div>
  <div class="swiper-pagination"></div>
</div>
                    </div>
                    <div class="ranking">
                        <a href="#">
                                                            <img src="//img.zing.vn/upload/ks3d/source/Banner/banner-mainsite/2021/vddenhat.png" alt="">
                                                        
                        </a>
                    </div>
                    <div class="block-account">
                        <a href="https://hotro.zing.vn/" class="btn-img btn-convert-account" id="convertAccount" onclick="ga('send', 'event', 'ConvertAccount', 'Button Image', 'Homepage', 1);"></a>
                        <a href="http://ttl3d.zing.vn/bai-viet/huong-dan/huong-dan-dung-code-tai-npc-cung-thai-van.html" class="btn-img btn-giftcode"></a>
                    </div>
                    <div class="home-news">
                        <div class="block-title">
                            <h3 class="btn-img news-title">Tin tức</h3>
                            <a href="//ttl3d.zing.vn/app_dev.php/tin-tuc/danh-sach.1.html" class="see-more">
                                <span class="plus"></span>
                                Xem thêm
                            </a>
                        </div>
                        <div id="newsContent">
                            <ul class="list-news">
                                                            <li>
      <a href="https://ttl3d.zing.vn/su-kien/de-nhat-cao-thu-thien-long-37/tin-tuc/ket-qua-de-nhat-cao-thu-thien-long-37-vong-chung-ket.html" title="Kết quả Đệ Nhất Cao Thủ Thiên Long 37 Vòng Chung Kết"  rel="nofollow">Kết quả Đệ Nhất Cao Thủ Thiên Long 37 Vòng Chung Kết       
      </a>
      <span class="post-date">10-01</span>
    </li>
                            <li>
      <a href="https://ttl3d.zing.vn/su-kien/thien-giang-minh-chau-643/thien-giang-minh-chau-3408.html" title="10/01: Chuỗi sự kiện tuần mới hoạt náo giang hồ"  rel="nofollow">10/01: Chuỗi sự kiện tuần mới hoạt náo giang hồ       
      </a>
      <span class="post-date">09-01</span>
    </li>
                            <li>
      <a href="//ttl3d.zing.vn/app_dev.php/tin-tuc/tin-tuc/10-01-thong-bao-bao-tri-may-chu.html" title="10/01: Thông báo bảo trì máy chủ"  rel="">10/01: Thông báo bảo trì máy chủ       
      </a>
      <span class="post-date">09-01</span>
    </li>
                            <li>
      <a href="https://ttl3d.zing.vn/su-kien/de-nhat-cao-thu-thien-long-37/tin-tuc/ket-qua-de-nhat-cao-thu-thien-long-37-vong-so-loai.html" title="Kết quả Đệ Nhất Cao Thủ Thiên Long 37 Vòng Sơ Loại"  rel="nofollow">Kết quả Đệ Nhất Cao Thủ Thiên Long 37 Vòng Sơ Loại       
      </a>
      <span class="post-date">08-01</span>
    </li>
                            <li>
      <a href="//ttl3d.zing.vn/app_dev.php/tin-tuc/tin-tuc/03-01-bao-tri-toan-bo-may-chu.html" title="03/01: Bảo trì toàn bộ máy chủ"  rel="">03/01: Bảo trì toàn bộ máy chủ       
      </a>
      <span class="post-date">02-01</span>
    </li>
  
                            </ul>
                        </div>
                        <div class="block-search">
    <form class="form-search" id="custom-search-form"  method="post" action="//ttl3d.zing.vn/app_dev.php/tim-kiem.1.html">
        <input type="text" placeholder="Nhập từ khóa cần tìm" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Nhập từ khóa cần tìm'" name="data[keyWord]" >
        <input type="submit" class="submit" value="Tìm Kiếm">
        <input type="hidden" value="KS3D" name="data[site]" >
        <input type="hidden" value="" name="data[fromDate]" >
        <input type="hidden" value="" name="data[toDate]" >
        <input type="hidden" value="<span class='BgKeySearch'>" name="data[preHL]" >
        <input type="hidden" value="</span>" name="data[postHL]" >
        <input type="hidden" value="0" name="data[page]" id="searchPage">
    </form>
</div>                    </div>
                    <div class="home-event">
                        <div class="block-title">
                            <h3 class="btn-img event-title">Sự kiện</h3>
                            <a href="//ttl3d.zing.vn/app_dev.php/su-kien/danh-sach.1.html" class="see-more">
                                <span class="plus"></span>
                                Xem thêm
                            </a>
                        </div>
                        <ul class="list-events">
                            													<li>
				<a href="//ttl3d.zing.vn/app_dev.php/su-kien/thien-giang-minh-chau-643/thien-giang-minh-chau-3408.html" title="Thiên Giáng Minh Châu"  >
					<img src="//img.zing.vn/upload/ks3d/source/Event/00-all-header/2022/05-09thumb.jpg" alt="Thiên Giáng Minh Châu">
					<div class="event-tail">
						<h3>Thiên Giáng Minh Châu</h3>
						<span class="post-date-event">10/01 - 16/01</span>
					</div>
				</a>
			</li>
													<li>
				<a href="//ttl3d.zing.vn/app_dev.php/su-kien/vang-danh-giang-ho-642/thien-giang-minh-chau-3402.html" title="Vang Danh Giang Hồ"  >
					<img src="//img.zing.vn/upload/ks3d/source/Event/00-all-header/2022/vangdanhthumb.jpg" alt="Vang Danh Giang Hồ">
					<div class="event-tail">
						<h3>Vang Danh Giang Hồ</h3>
						<span class="post-date-event">03/01 - 10/01</span>
					</div>
				</a>
			</li>
													<li>
				<a href="//ttl3d.zing.vn/app_dev.php/su-kien/nhat-dai-phu-gia/qua-tang-nap-the-3390.html" title="Nhất Đại Phú Gia"  >
					<img src="//img.zing.vn/upload/ks3d/source/Event/00-all-header/2022/phugiathumb.jpg" alt="Nhất Đại Phú Gia">
					<div class="event-tail">
						<h3>Nhất Đại Phú Gia</h3>
						<span class="post-date-event">27/12 - 02/01</span>
					</div>
				</a>
			</li>
	
                        </ul>
                    </div>
                    <div class="media">
                        <a href="#" class="btn-img btn-video"></a>
                        <a href="#" class="btn-img btn-image"></a>
                        <a href="#" class="btn-img btn-music"></a>
                        <a href="https://www.facebook.com/ttl3d" class="btn-img btn-fanpage"></a>
                    </div>
                    <div class="guide">
                        <a href="https://ttl3d.zing.vn/bai-viet/huong-dan/giao-dien-tro-choi.html" class="btn-img btn-guide-newbie"></a>
                        <a href="https://ttl3d.zing.vn/bai-viet/huong-dan/su-do.html" class="btn-img btn-guide-feature"></a>
                        <a href="https://ttl3d.zing.vn/bai-viet/huong-dan/cap-1-cap-20.html" class="btn-img btn-guide-level"></a>
                        <a href="https://ttl3d.zing.vn/bai-viet/huong-dan/huong-dan-nap-bac.html" class="btn-img btn-guide-topup"></a>
                    </div>
                    <div class="home-character">
                        <div class="swiper-container" id="homeCharacter">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/duongmon.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/ngami.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/vodang.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/minhgiao.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/thieulam.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#0" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/caibang.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/daohoa.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/thienlong.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/modung.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/thienson.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/tieudao.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/tinhtuc.jpg" alt="" /></a></div>
<div class="swiper-slide"><a href="#" target="_blank"><img src="//img.zing.vn/upload/ks3d/source/News/2021/slide/quycoc.jpg" alt="" /></a></div>                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                    <div class="tournament">
                            <ul class="tournament-list">
<li><a href="https://ttl3d.zing.vn/su-kien/sinh-tu-loi-dai/ket-qua-chung-cuoc-3169.html" target="_blank" rel="noopener"> <img src="//img.zing.vn/upload/ks3d/source/Banner/banner-mainsite/2022/1stld.png" alt="" /> </a></li>
<li><a href="https://ttl3d.zing.vn/tin-tuc/tin-tuc/ket-qua-huyet-chien-trac-loc-co-thien-long-34.html" target="_blank" rel="noopener"> <img src="//img.zing.vn/upload/ks3d/source/Banner/banner-mainsite/2022/2hctlc.png" alt="" /> </a></li>
<li><a href="https://ttl3d.zing.vn/su-kien/de-nhat-cao-thu-thien-long-34/tin-tuc/ket-qua-chung-cuoc-giai-dau-de-nhat-cao-thu-thien-long-34.html" target="_blank" rel="noopener"> <img src="//img.zing.vn/upload/ks3d/source/News/2021/t7/bandnct.jpg" alt="" /> </a></li>
<li><a href="https://ttl3d.zing.vn/su-kien/de-nhat-cao-thu-thien-long-33/the-le-2881.html" target="_blank" rel="noopener"> <img src="//img.zing.vn/upload/ks3d/source/News/2021/t7/bandnct.jpg" alt="" /> </a></li>
</ul>                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
<div class="container">
<div class="block-logo"><a><img src="//img.zing.vn/upload/ks3d/source/News/2022/thaylogo.png" /></a> <a><img src="//img.zing.vn/products/ks3d/skin-2021/images/logo-changyou.png" alt="" /></a></div>
<p class="address">Công ty cổ phần VNG. <span>Z06, Đường 13, phường Tân Thuận Đông, Quận 7, Thành phố Hồ Chí Minh, Việt Nam.</span><br />Giấy phép cung cấp dịch vụ trò chơi điện tử G1 trên mạng số: 251/GP-BTTTT<br /> do Bộ Thông tin và Truyền thông cấp ngày 22/6/2015.<br /> Quyết định phê duyệt nội dung kịch bản trò chơi điện tử G1 trên mạng số: 1735/QĐ-BTTTT<br /> do Bộ Thông tin và Truyền thông cấp ngày 20/10/2016.</p>
</div>
</footer>    </div>
    <script src="//img.zing.vn/products/ks3d/skin-2014/js/skin-homepage-v25.js"></script>
    <script src="//img.zing.vn/products/vendor/jquery/jquery-1.11.1.min.js"></script>
    <script src="//img.zing.vn/products/vendor/swiper/2019/swiper.min.js"></script>
    <script src="//img.zing.vn/products/ks3d/skin-2021/js-full/main.js"></script>
    <script>
    window.initCsLiveChat = () => {
        CsLiveChat.init({
            loginMode: 'login_required',
            loginMethods: ['zing'],
            liveChatConfig: {
                appKey: 'VNGCORPORATION_app_f2cb84b795fe4286b4cf543c01e0f830',
                domain: 'vngcorporation.aihelp.net',
                appId: 'vngcorporation_platform_dc26d97c8454910d302262d3dbd2b7e7',
                language: 'vi',
                apiConfig: {
                    entranceId: 'E002',
                    welcomeMessage: '',
                },
                supportMode: 'showConversation',
                supportConfig: {
                    conversationIntent: 2,
                    welcomeMessage: 'Welcome!',
                },
            },
            metaData: {
                liveChat: {
                    userTags: 'hashtag1,hashtag2',
                    customData: {
                        key1: 'value1',
                        key2: 'value2',
                    },
                },
            },
        });
        CsLiveChat.show();
    };
    (function (d) {
        const CS_LIVE_CHAT_SCRIPT_ID = 'cs-live-chat-ref';
        if (d.getElementById(CS_LIVE_CHAT_SCRIPT_ID)) {
            window.initCsLiveChat();
            return; //Exit
        } //no else
        let csLiveChatLibScriptElem = d.createElement('script');
        csLiveChatLibScriptElem.id = CS_LIVE_CHAT_SCRIPT_ID;
        csLiveChatLibScriptElem.src = `https://chat.support.vnggames.com/cslivechat/app.js?ts=${(new
        Date()).getTime()}`;
        csLiveChatLibScriptElem.onload = window.initCsLiveChat;
        let firstScriptElem = d.getElementsByTagName('script')[0];
        firstScriptElem.parentNode.insertBefore(
            csLiveChatLibScriptElem,
            firstScriptElem
        );
    })(document);
</script></body>

</html>
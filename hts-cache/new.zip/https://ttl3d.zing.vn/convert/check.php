﻿<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]> <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]> <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <link rel="shortcut icon" href="//img.zing.vn/products/ks/skin-2014/images/favorite.gif" />
        <link type="text/css" rel="stylesheet" href="//img.zing.vn/products/ks/convert/css/ks-convert-form.min.css" />
        <title>Kiểm tra chuyển đổi tài khoản </title>
		<style>
			.lable{
				float: left;
				margin-left: 88px;
				margin-top: 12px;
				width: 112px;
			}
			.inputtext{margin-left: 11px !important}
			.ks-convert-account-form{height:471px}
			.ks-convert-account-form-submit-btn{margin-left: 210px;}

		</style>
    </head>
    <body>
	<div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header">
			<h3 id="ks-convert-account-popup-title" data-text="Chuyển đổi tài khoản" data-alt-text="Đăng ký tài khoản ZingID">Kiểm tra chuyển đổi tài khoản</h3>
		</div>
		<div class="modal-body" id="ks-modal-content">
		 <div class="ks-convert-account-form-wrapper">
            <div class="ks-convert-account-form">
                <div id="ks-login-fid" class="ks-convert-account-fid ks-convert-account-form-content ks-convert-panel-view">
                    <div class="row">
					<p class="ks-alert ks-alert-alt01 text-center"> Đăng nhập tài khoản <strong>ZingID</strong> để kiểm tra chuyển đổi</p>
                <form action="https://sso3.zing.vn/xlogin" id="iframe-zingid-login-form" method="post">
                    <div class="form-group ks-form-group">
					<lable><span class="lable">Tài khoản ZingID:</span> <input type="text" placeholder="Tài khoản ZingID" class="form-control ks-text-input inputtext" id="iframe-zingid" name="u" /></lable>
                    </div>
					<div class="form-group ks-form-group">
					<lable><span class="lable">Mật khẩu ZingID:</span> <input type="password"  placeholder="Mật khẩu ZingID" class="form-control ks-text-input inputtext" id="iframe-zingid-pwd" name="p" /><lable>
                    </div>
					<div class="form-group ks-convert-account-form-btn-group">
                        <button type="submit" class="btn btn-lg btn-default ks-convert-account-form-submit-btn-style ks-convert-account-form-submit-btn" data-normal-text="Đăng nhập" data-loading-text="Đang đăng nhập ZingID">Đăng nhập</button>
					</div>

                    <input type="hidden" name="longtime" id="longtime" value="0">
                    <input type="hidden" name="u1" value="http://ttl.zing.vn/convert/check.php">
                    <input type="hidden" name="fp" value="http://ttl.zing.vn/convert/check.php">
                    <input type="hidden" name="pid" value="239">
                    <input type="hidden" name="apikey" value="3a29ac50e07c4a7888cd002def807938">
					
			   </form>
            			</div>		</div>
                    </div>
					</div>
		  <!-- END. convert form content -->
                </div>
            </div>
        </div>
    </body>
</html>

